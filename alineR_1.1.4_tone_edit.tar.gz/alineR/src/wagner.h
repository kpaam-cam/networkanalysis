void align(Word *w1, Word *w2, int *score, char aback1[50], char aback2[50], int vec[12], int skippen);
